let decode_order cells : (order, err) result =
  match cells with
  | [sym; qty_s; px_s] ->
    let open Result in
    let* qty =
      match int_of_string_opt qty_s with
