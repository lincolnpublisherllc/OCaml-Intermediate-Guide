let v_order sym qty px =
  let v_sym =
    let s = String.trim sym in
    if s = "" then err (Domain "empty sym") else ok (String.uppercase_ascii s)
