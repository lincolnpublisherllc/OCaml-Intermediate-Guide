let test_ok () =
  match Csvx.decode_order ["AAPL"; "5"; "1.2"] with
  | Ok _ -> ()
