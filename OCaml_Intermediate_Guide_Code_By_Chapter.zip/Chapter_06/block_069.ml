Wrap and print:
Introduce a services.err type that wraps csvx.err. Plumb it through one public function and print a single user-facing line like:
error: csv: bad int qty="x9" (line=42).
Property test a decoder:
Generate random triples (sym, qty, px) and assert that when qty>0 && px>0 the decoder accepts, otherwise rejects with a specific error.
