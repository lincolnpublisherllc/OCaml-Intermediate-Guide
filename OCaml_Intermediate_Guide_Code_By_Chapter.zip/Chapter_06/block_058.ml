Copy only the failing function and its types.
Replace I/O with in-memory strings or lists.
