let%test "decode bad qty" =
  match decode_order ["MSFT"; "nope"; "2.5"] with
  | Error (Bad_int {field="qty"; _}) -> true
