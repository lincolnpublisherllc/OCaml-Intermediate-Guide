type 'a v = ('a, err list) result  (* collect many *)
