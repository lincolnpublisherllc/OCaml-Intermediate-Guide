let load path : (order list, E.t) result =
  let open Result in
  let* lines =
