let test_bad_arity () =
  match Csvx.decode_order ["only1"] with
  | Error (Csvx.Bad_arity _) -> ()
