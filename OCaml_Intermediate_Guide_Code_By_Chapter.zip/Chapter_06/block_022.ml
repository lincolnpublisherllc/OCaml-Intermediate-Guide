let v_qty =
    match int_of_string_opt qty with
