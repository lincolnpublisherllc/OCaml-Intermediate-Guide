Ok { sym = String.uppercase_ascii sym; qty; px }
  | cells -> Error (Bad_arity (List.length cells))
Propagate with intent
