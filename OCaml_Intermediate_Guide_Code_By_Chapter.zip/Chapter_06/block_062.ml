let rec fold i ok errs = function
    | [] -> Ok (List.rev ok), List.rev errs
    | l::ls when l="" -> fold (i+1) ok errs ls
