let map2 f a b =
  match a, b with
  | Ok x, Ok y -> Ok (f x y)
