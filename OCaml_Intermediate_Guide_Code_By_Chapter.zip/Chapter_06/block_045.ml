let log level ?(ctx=[]) msg =
  let fields =
