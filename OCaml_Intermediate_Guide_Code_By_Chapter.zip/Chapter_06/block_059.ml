module E = struct
  type t = Csv of Csvx.err | Io of string
  let pp fmt = function
