Error type per module with pp
