let () = QCheck_alcotest.run ~compact:true "props" [prop_total_nonneg]
