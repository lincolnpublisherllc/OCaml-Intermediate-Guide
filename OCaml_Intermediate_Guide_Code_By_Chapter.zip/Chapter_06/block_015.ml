let read_file path : (string list, err) result =
  try Ok (In_channel.with_open_text path In_channel.input_all |> String.split_on_char '\n')
  with Sys_error m -> Error (Io m)
