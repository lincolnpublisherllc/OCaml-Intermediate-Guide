let ok x : 'a v = Ok x
let err e : 'a v = Error [e]
