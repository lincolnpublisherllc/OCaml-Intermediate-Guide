Debug checklist drill:
Break a test on purpose (off-by-one in aggregation). Use the checklist: reproduce with a 5-line fixture, add two logs, enable backtrace, fix, remove logs.
