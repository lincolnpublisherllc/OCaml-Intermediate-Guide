match Csvx.decode_order (String.split_on_char ',' l) with
      | Ok o -> fold (i+1) (o::ok) errs ls
      | Error e -> fold (i+1) ok ((i,e)::errs) ls
