Non-deterministic tests: replace Hashtbl iteration with Map.bindings |> List.iter.
OOM / slow: switch to line/seq streaming; batch writes; avoid building giant strings with ^.
Heisenbug (timing): add IDs to logs, lock concurrency model (Chapter 7), reduce parallelism while debugging.
Data drift: version your decode (e.g., v1, v2 record tags), log unknown fields, keep strict decoders.
