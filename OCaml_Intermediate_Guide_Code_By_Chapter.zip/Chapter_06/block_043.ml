If output changes unexpectedly, the test fails. When you intend to update it, re-record with care.
