let* px =
      match float_of_string_opt px_s with
