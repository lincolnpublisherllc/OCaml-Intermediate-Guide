Start simple: function + level + message. Add fields as key=value so logs parse easily.
type level = Debug | Info | Warn | Error
let pp_level fmt = function
