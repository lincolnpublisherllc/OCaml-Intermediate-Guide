let ok, errs = fold 1 [] [] lines in
  (* log once per error kind *)
  let tbl = Hashtbl.create 8 in
  List.iter (fun (_i,e) ->
    Hashtbl.replace tbl e (1 + Option.value ~default:0 (Hashtbl.find_opt tbl e))) errs;
  Hashtbl.iter (fun e n -> Format.eprintf "[warn] %d x %a@." n Csvx.pp_err e) tbl;
