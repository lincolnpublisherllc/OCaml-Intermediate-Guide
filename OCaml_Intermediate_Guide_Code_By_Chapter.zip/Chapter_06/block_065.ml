The function returns decoded values or an I/O failure, nothing else.
