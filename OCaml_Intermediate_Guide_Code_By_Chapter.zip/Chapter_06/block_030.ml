let%test "decode ok" =
  match decode_order ["MSFT"; "10"; "2.5"] with
  | Ok {sym; qty; px} -> sym="MSFT" && qty=10 && px=2.5
