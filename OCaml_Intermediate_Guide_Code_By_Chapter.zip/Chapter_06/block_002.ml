Define small error domains per module
Keep errors close to where they’re produced. Give each module its own error type and a pretty-printer.
(* csvx.mli *)
type err =
