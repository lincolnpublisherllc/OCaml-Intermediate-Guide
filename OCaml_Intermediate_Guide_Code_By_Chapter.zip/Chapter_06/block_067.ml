Wrap low-level errors once with context
