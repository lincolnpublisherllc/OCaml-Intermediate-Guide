let parse_line l : (order, err) result =
  Csvx.decode_order (String.split_on_char ',' l) |> Result.map_error (fun e -> Csv e)
