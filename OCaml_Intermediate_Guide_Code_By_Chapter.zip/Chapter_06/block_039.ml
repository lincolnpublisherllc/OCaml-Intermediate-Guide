let gen_pos_int = small_nat |> map (fun n -> n + 1)
