| Error e -> Error (ctx ^ ": " ^ e)  (* adjust for your error type *)
