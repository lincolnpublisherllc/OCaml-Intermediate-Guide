let prop_total_nonneg =
  Test.make ~name:"total>=0"
    (pair gen_pos_int (float_range 0.0001 1_000.0))
    (fun (qty, px) ->
       let notional = float_of_int qty *. px in
       notional >= 0.)
