let pp_err fmt = function
  | Bad_arity n -> Format.fprintf fmt "bad arity (%d cells)" n
  | Bad_int {field; got} -> Format.fprintf fmt "bad int %s=%S" field got
  | Bad_float {field; got} -> Format.fprintf fmt "bad float %s=%S" field got
