let v_px =
    match float_of_string_opt px with
