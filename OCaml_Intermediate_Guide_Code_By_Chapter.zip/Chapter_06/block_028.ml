QCheck (with Alcotest or standalone): property‐based tests.
