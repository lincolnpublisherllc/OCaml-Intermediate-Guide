Reproduce with the smallest input. If you can’t, you don’t control the bug yet.
Read the first error (not the last). Fix it; re-run.
