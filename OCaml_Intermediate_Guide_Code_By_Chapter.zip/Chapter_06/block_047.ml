let line = if fields="" then msg else msg ^ " " ^ fields in
