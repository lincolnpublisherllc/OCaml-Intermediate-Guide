Don’t let objects leak everywhere—accept a small object type or module type at boundaries.
If you start adding many downcasts or dynamic checks, step back: can a variant + pattern match serve you better?
