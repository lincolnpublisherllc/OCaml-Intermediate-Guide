module Flat (F : sig val f : float end) : FEE = struct
  let fee _ = F.f
