module Make_cache (C : CLOCK) = struct
  let created = C.now ()
  let hits = ref 0
  let get () = incr hits; (created, !hits)
