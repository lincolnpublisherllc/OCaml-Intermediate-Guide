let fee s notional =
  match s with
