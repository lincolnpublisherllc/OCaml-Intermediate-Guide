let total (calc : fee) notional = notional +. calc#fee notional
