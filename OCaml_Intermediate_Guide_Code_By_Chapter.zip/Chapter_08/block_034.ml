let eval (p : program) : float option =
  let step st = function
    | Push x -> Some (x :: st)
