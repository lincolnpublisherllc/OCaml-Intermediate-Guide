Heavier, but methods are pluggable at runtime. Use this if node types are open and you inject behaviors as objects.
