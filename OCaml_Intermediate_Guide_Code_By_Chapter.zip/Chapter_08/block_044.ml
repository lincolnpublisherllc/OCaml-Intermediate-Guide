Static policy per build → functor over a signature
Runtime plugin choice / callbacks → first-class module or object
Stateful instance with overridable behavior → object
