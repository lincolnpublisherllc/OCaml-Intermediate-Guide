Provide a fake implementation via functor arg or first-class module
