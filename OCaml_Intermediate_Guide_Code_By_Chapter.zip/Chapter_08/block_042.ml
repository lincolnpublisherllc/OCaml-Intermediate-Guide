let run h lines =
  List.iter (fun l -> h#on_line l) lines; h#close ()
You can ship a list of heterogeneous handlers (all with the same methods) and chain them.
