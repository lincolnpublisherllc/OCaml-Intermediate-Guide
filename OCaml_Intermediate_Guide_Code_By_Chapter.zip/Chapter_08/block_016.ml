B) As a module (static injection)
module type FEE = sig val fee : float -> float end
module Percent (R : sig val r : float end) : FEE = struct
  let fee notional = notional *. R.r
