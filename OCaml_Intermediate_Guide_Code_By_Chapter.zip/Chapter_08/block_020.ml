If you need to add operations and keep instances with methods, objects fit.
