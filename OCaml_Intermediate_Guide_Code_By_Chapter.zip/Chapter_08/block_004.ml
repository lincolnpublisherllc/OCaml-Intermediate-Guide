When new behaviors appear as separate plugins, or you need instances with evolving state and late binding, objects are convenient.
