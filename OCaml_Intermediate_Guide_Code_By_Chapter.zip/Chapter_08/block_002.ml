type side = Buy | Sell
let describe = function Buy -> "buy" | Sell -> "sell"
