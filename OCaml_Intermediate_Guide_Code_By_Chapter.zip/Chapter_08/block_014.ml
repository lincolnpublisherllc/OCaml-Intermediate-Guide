A) As a variant + match (closed set; simple)
type fee_strategy = Percent of float | Flat of float
