match List.fold_left (fun s i -> Option.bind s (fun st -> step st i)) (Some []) p with
  | Some [x] -> Some x
