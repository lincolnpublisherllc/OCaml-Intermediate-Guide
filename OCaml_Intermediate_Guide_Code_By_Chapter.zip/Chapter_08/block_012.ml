module Stdout : LOG = struct let info s = Printf.printf "[INFO] %s\n" s end
let () = run (module Stdout) (fun () -> ())
Pros: choose implementations dynamically (tests, flags).
Cons: some indirection; fewer compile-time optimizations.
