If swapping is per build/config → functor.
If swapping is per request/runtime → first-class module.
