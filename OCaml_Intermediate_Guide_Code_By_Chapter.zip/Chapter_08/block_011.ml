let run (module L : LOG) job =
  L.info "start"; job (); L.info "done"
