Interpreters are natural with variants and higher-order functions. Push effects to the edges; keep the AST and evaluator pure.
type instr =
