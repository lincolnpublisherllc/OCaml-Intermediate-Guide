| Add (a,b) -> "(" ^ pretty a ^ " + " ^ pretty b ^ ")"
  | Neg e -> "(-" ^ pretty e ^ ")"
Add a new operation? Write a new function. The compiler ensures you covered all constructors.
Object-based visitor (open set of node types)
class type ['r] expr = object method accept : ('r #visitor) -> 'r end
and ['r] visitor = object
