module Sys_clock = struct let now () = Unix.gettimeofday () end
module Cache = Make_cache(Sys_clock)
Pros: no runtime overhead, errors at compile time.
Cons: you can’t swap at runtime without rebuilding (unless you use first-class modules).
First-class modules: runtime injection (flexible)
Wrap a module in a value and pass it at runtime.
module type LOG = sig val info : string -> unit end
