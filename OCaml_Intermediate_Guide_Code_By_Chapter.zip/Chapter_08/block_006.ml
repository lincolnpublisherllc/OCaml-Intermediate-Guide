Evolving state with method overrides in a test double.
Typical non-wins (prefer ADTs/modules instead):
