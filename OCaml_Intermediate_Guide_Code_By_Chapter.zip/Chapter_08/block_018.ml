class type fee = object method fee : float -> float end
class percent r : fee = object method fee n = n *. r end
