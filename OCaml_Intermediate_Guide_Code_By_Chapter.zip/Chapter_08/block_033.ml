type program = instr list
