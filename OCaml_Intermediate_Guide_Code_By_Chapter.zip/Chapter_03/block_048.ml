match Row.to_tuple row with
       | Ok (sym, qty, price) -> f acc ~sym ~qty ~price
