module Cache_str =
  Cache.Make(Sys_clock)(struct type t = string let compare = String.compare end)
Benefits:
