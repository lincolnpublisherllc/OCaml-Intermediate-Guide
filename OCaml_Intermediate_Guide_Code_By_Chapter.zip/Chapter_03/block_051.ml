One responsibility per module
