Use a functor when a module’s behavior varies by a dependency you can describe as a signature. You get compile-time checking and zero runtime overhead.
Caching with a pluggable clock
