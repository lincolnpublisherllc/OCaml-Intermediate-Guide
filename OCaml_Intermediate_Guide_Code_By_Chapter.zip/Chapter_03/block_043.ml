3.8 Code tour: wiring a service with an interface boundary
