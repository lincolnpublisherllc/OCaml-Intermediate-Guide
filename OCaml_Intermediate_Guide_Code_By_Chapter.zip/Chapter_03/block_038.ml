type io = {
  read_lines : string -> string list;
  write_lines : string -> string list -> unit;
