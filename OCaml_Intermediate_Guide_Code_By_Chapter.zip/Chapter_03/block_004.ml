Namespacing with directories
Dune treats each file as a module named by the capitalized file. For light namespacing, create subdirs and a dune that builds a single library:
