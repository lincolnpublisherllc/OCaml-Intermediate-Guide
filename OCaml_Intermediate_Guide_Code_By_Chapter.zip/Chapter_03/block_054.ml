Refactor in short steps and let Dune and the compiler guard you.
