This makes debugging and CLI output easier and helps with property tests later.
