Every public type should have:
