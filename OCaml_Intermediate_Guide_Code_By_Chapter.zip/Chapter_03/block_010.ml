let of_float x = if x >= 0. then Some (P x) else None
let unsafe_of_float x = P x
let to_float (P x) = x
