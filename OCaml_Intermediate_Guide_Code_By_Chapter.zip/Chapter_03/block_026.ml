module type LOG = sig val info : string -> unit end
let run (module L : LOG) = L.info "start"
