type exposure = { sym : string; notional : float }
