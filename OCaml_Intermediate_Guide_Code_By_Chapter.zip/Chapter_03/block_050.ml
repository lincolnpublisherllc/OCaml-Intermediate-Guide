let exposures = Service_exposure.compute (module Csv_feed) "pos.csv" in
  exposures |> List.iter (fun e -> Printf.printf "%s %.2f\n" e.sym e.notional)
You can drop in a DB feed or HTTP feed with the same signature without touching Service_exposure.
