let discount (P x) ~rate =
  let r = max 0.0 (min 1.0 rate) in
  P (x *. (1.0 -. r))
