When not to use a functor
