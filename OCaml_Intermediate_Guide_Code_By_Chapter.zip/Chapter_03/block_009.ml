type t = P of float
