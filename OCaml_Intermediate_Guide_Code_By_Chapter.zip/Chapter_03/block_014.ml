Pretty printers and infix ops live next to the type.
