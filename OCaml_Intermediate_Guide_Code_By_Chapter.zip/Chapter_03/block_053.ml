Abstract a type
Turn a float volume into Volume.t with a nonnegative invariant. Provide of_float, to_float, add, pp. Hide the constructor.
Invert a dependency
A function load_and_value : string -> float reads CSV and returns a value. Split it into Csv_feed : FEED and Value.compute : (module FEED) -> 'src -> float.
Replace a runtime if with a functor
You switch between Sys_clock and Fixed_clock using a flag. Replace with Cache.Make(CLOCK) and remove the flag from hot paths.
Split an app
Move 100 lines of logic out of main.ml into a library and expose a 5-function API in .mli. Keep main.ml under 30 lines.
