module Sys_clock = struct let now () = Unix.gettimeofday () end
module Test_clock = struct
  let t = ref 0.0
  let now () = !t
