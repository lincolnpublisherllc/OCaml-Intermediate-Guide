Services depend on domain, sometimes on adapters via interfaces (module types).
