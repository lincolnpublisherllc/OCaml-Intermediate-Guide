Replace original calls with New_module.fn.
