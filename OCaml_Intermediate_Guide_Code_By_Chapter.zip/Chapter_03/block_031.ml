Strategy A: extract module behind a signature
