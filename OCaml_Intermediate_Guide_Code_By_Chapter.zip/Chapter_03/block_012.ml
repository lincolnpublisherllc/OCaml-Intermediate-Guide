let ( + ) (P a) (P b) = P (a +. b)
