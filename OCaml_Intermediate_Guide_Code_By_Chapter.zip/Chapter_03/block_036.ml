Strategy C: replace data constructors with smart constructors
If a type leaks invalid states, hide it behind an abstract type and provide of_* functions. Do this first in the .mli, then adapt callers.
