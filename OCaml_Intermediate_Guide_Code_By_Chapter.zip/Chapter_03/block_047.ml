let fold file ~init ~f =
