let compute (type p) (module F : Position_feed.S with type t = p) (src : p) =
  F.fold src ~init:[] ~f:(fun acc ~sym ~qty ~price ->
    let notional = float_of_int qty *. Price.to_float price in
    { sym; notional } :: acc)
