module Make (C : Clock.S) (K : Map.OrderedType) : S with type key = K.t = struct
  module M = Map.Make(K)
  type key = K.t
  type 'a entry = { v : 'a; ts : float }
  type 'a t = { mutable m : 'a entry M.t }
