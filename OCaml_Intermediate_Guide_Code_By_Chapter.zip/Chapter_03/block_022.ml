let create () = { m = M.empty }
  let put t k v = t.m <- M.add k { v; ts = C.now () } t.m
  let get t k = Option.map (fun e -> e.v) (M.find_opt k t.m)
  let age t k = Option.map (fun e -> C.now () -. e.ts) (M.find_opt k t.m)
