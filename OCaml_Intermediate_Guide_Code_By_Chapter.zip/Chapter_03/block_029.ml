let () =
  match Sys.argv |> Array.to_list with
  | [_; file] ->
      let rows = Csvx.read file in
