let pp fmt (P x) = Format.fprintf fmt "%.4f" x
