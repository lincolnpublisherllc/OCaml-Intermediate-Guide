Keep exceptions for truly exceptional situations. Prefer ('ok, 'err) result across module boundaries so callers can handle errors without try/with in many places.
