Strategy B: invert a dependency with a module type
You have Service calling Adapter_csv. You want Service to work with any adapter.
Before:
