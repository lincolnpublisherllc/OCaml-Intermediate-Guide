let () =
  let module Csv_feed = (val (module struct
    type t = string
    let fold = Adapter_csv.fold
  end : Position_feed.S with type t = string)) in
