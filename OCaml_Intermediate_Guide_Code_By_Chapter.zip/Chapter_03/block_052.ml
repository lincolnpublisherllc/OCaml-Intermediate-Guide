Small steps with green builds
