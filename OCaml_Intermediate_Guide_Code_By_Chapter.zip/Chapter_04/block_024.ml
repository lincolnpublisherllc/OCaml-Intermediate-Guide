let in_range ~lo ~hi (m : TS.t) =
  (* all bindings with key in [lo, hi] inclusive *)
  let rec take_from k m acc =
    match TS.split k m with
    | (_, None, right) -> acc, right
    | (_, Some v, right) -> ((k, v) :: acc), right
