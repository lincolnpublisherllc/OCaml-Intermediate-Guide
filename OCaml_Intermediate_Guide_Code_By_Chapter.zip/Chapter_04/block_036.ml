let parse_row (sym_s, qty_s, px_s) : quote option =
  match int_of_string_opt qty_s, float_of_string_opt px_s with
  | Some qty, Some px when qty > 0 && px > 0. -> Some { sym = String.uppercase_ascii sym_s; qty; px }
