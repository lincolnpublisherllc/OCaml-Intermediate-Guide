type trade = { sym : string; qty : int; px : float; ccy : string }
