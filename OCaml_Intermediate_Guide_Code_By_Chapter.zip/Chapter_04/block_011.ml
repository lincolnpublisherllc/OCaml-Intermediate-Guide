Map.Make(Ord) and Set.Make(Ord) build persistent balanced trees (red-black under the hood). You supply an Ord module with type t and compare : t -> t -> int.
