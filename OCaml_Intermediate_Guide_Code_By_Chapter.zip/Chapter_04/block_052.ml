Case-insensitive index
Create module Sym_ci : Map.OrderedType and a Map from case-insensitive symbols to last price. Write upsert : string -> float -> m -> m and get : string -> m -> float option that treat "msft" and "MSFT" as the same key.
Range query
Using the composite key (date * sym), implement between : (date * sym) -> (date * sym) -> float TS.t -> ((date * sym) * float) list.
Map merge for P&L
Given two Map<string,float> snapshots (prev and curr) of notional by symbol, compute pnl = curr - prev as a Map. Remove zero entries.
Tuples → record refactor
Start with a function that threads (sum, count, min, max) as a 4-tuple. Refactor to a record with field punning and a clear update helper.
