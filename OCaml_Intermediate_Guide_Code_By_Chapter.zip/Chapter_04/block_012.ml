module Sym = struct type t = string let compare = String.compare end
module Sym_map = Map.Make(Sym)
