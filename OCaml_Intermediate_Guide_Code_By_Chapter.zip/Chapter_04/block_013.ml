type date = int (* yyyymmdd; use a real date type in production *)
