(* Compare two position snapshots by symbol *)
module M = Sym_map
type diff = { only_a : int; only_b : int; delta : int option }
