module Make_map (Ord : Map.OrderedType) = struct
  module M = Map.Make(Ord)
  let of_kv_list kvs =
    List.fold_left (fun m (k,v) -> M.add k v m) M.empty kvs
  let inc k m =
    M.update k (function None -> Some 1 | Some n -> Some (n+1)) m
