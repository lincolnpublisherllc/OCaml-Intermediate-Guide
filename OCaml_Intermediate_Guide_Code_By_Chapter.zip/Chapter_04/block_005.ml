(* Deterministic report: Map *)
module Sym = struct type t = string let compare = String.compare end
module M = Map.Make(Sym)
