module Sym_ci = struct
  type t = string
  let compare a b = String.compare (String.uppercase_ascii a) (String.uppercase_ascii b)
