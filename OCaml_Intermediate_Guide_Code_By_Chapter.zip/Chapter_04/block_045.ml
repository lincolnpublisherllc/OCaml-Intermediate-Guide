let dedup_syms xs =
  xs |> List.fold_left (fun acc s -> S_ci.add s acc) S_ci.empty |> S_ci.elements
