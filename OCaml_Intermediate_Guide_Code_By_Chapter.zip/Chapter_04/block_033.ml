let normalize_trade t =
  let sym = String.uppercase_ascii t.sym in
  let notional = float_of_int t.qty *. t.px in
  { t with sym; (* record punning *)
           (* keep qty/px/ccy as-is *)
