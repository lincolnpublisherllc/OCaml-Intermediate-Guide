(* Hot counter: Hashtbl *)
let freq (xs : string list) =
  let t = Hashtbl.create 1024 in
