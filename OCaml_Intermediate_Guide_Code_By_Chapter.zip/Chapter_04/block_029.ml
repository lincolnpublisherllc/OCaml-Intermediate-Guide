let tradable universe banned =
  S.diff universe banned  (* also S.union, S.inter, S.mem, S.elements *)
