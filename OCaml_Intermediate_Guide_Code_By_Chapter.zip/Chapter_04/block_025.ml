let _, right_of_lo = TS.split lo m in
  let rec loop cur acc =
    match TS.min_binding_opt cur with
