Hot paths with millions of lookups/updates and order doesn’t matter.
Keys are basic types with good hash/equality (int, string) or you control hashing.
You’re okay with mutation and non-stable iteration.
