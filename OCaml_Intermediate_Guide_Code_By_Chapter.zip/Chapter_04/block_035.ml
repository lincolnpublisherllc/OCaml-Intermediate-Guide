type row = string * string * string  (* sym, qty, px *)
type quote = { sym : string; qty : int; px : float }
