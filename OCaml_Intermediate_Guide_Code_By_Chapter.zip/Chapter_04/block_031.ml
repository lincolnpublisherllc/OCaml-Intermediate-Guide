let normalize (sym, qty, px) =
  let sym = String.uppercase_ascii sym in
  let notional = float_of_int qty *. px in
  (sym, notional)
