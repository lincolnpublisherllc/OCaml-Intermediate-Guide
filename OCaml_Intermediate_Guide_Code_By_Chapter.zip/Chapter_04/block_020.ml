let bump sym m =
  M.update sym (function None -> Some 1 | Some k -> Some (k + 1)) m
