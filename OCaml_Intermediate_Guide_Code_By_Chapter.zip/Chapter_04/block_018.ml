Trees rely on a total order. Ensure compare is transitive and consistent with equality.
