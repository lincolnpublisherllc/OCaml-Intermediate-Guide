let reconcile a b =
