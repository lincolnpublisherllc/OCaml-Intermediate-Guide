match qa, qb with
    | Some x, Some y -> Some { only_a = 0; only_b = 0; delta = Some (x - y) }
    | Some x, None   -> Some { only_a = x; only_b = 0; delta = None }
    | None,   Some y -> Some { only_a = 0; only_b = y; delta = None }
