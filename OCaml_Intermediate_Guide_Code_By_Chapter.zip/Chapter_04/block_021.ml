let union_sum a b =
  M.union (fun _ v1 v2 -> Some (Option.value ~default:0 v1 + Option.value ~default:0 v2)) a b
