(* M.bindings m is sorted by sym *)
