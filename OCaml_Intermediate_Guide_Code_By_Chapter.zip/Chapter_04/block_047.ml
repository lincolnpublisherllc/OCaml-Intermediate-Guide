Batch transforms with Map.merge/union rather than many tiny adds if you can pre-sort data.
Avoid repeated @ on lists; build with :: and List.rev.
When using Hashtbl, pre-size with create and prefer replace over add if keys repeat.
