You need composite keys with custom ordering (e.g., (date * symbol)).
