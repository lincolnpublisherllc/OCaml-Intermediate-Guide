let notional_by_sym (rows : (string * float) list) =
