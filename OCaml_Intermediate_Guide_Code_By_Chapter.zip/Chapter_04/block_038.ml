let add_tick (m : float By_bucket.t) ~(bucket:bucket) ~(sym:string) (px:float) =
  let k = (bucket, sym) in
  let v0 = Option.value ~default:0.0 (By_bucket.find_opt k m) in
