let intersect a b =
