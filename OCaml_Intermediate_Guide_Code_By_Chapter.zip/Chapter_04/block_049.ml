module Make_set (Ord : Map.OrderedType) = struct
  module S = Set.Make(Ord)
  let of_list = List.fold_left (fun acc x -> S.add x acc) S.empty
