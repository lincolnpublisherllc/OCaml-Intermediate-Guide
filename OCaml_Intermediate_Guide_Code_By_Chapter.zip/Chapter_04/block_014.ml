module K = struct
  type t = date * string
  let compare (d1,s1) (d2,s2) =
    match Int.compare d1 d2 with
