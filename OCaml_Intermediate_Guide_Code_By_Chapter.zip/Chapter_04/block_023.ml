match va, vb with
    | Some x, Some y -> Some (min x y) | _ -> None) a b
