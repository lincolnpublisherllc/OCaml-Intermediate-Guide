A) Time-bucketed aggregation (Map with composite key)
type bucket = int  (* e.g., 20250130_10 for 10:00 *)
module BK = struct type t = bucket * string let compare = K.compare end
module By_bucket = Map.Make(BK)
