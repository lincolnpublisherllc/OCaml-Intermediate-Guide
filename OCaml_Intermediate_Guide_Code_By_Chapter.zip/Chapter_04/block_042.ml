module S = Set.Make(Sym)
let tradable universe blacklist = S.diff universe blacklist
let universe_from_map m = m |> M.to_seq |> Seq.map fst |> S.of_seq
