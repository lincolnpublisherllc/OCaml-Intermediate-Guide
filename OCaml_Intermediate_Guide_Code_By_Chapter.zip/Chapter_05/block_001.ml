File Handling and Working with External Data
