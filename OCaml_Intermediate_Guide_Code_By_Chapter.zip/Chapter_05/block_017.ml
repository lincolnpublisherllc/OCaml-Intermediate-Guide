let errors =
    errors |> Hashtbl.to_seq |> List.of_seq |> List.sort (fun a b -> compare (snd b) (snd a))
