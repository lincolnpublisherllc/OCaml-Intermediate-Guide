(* Example uses Yojson.Basic, but the pattern carries over *)
type quote = { sym : string; bid : float; ask : float }
