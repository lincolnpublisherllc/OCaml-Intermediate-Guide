let decode_order (cells : string list) : (order, csv_err) result =
  match cells with
  | [sym; qty_s; px_s] ->
      let sym = String.uppercase_ascii (String.trim sym) in
