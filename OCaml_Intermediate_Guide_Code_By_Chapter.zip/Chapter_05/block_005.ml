let lines filename : string Seq.t =
  let open Seq in
  fun () ->
    let ic = open_in filename in
    let rec step () =
      match input_line ic with
      | line -> Cons (line, step)
