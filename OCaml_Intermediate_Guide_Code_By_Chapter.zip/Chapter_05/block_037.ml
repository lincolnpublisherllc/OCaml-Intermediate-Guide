type agg = { qty : int; notional : float }
