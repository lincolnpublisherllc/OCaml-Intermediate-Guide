let rows_of_map (m : agg M.t) : row list =
