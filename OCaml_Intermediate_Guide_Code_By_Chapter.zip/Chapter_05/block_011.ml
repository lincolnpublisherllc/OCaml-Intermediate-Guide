begin match int_of_string_opt qty_s with
      | None -> Error (Bad_qty qty_s)
      | Some qty when qty <= 0 -> Error (Bad_qty qty_s)
