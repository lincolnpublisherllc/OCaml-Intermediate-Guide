let run infile outfile =
  let (m, errs) = aggregate_orders infile in
  errs |> List.iter (fun (e,c) -> Printf.eprintf "[warn] %d x %s\n" c
                                    (match e with
