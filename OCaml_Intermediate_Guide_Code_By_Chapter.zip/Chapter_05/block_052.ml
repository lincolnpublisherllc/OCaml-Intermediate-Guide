let write_lines filename (xs : string list) =
