Step 2: group by symbol (deterministic)
module Sym = struct type t = string let compare = String.compare end
module M = Map.Make(Sym)
