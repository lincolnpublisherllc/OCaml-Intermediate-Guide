Merge sorted runs with a k-way merge using a min-heap.
