let read_all filename =
