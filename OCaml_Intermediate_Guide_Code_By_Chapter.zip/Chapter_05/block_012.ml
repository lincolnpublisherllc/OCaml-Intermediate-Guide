match float_of_string_opt px_s with
        | None -> Error (Bad_px px_s)
        | Some px when px <= 0.0 -> Error (Bad_px px_s)
        | Some px -> Ok { sym; qty; px }
