JSON Lines filter
Given JSON lines with {"sym": "...", "v": float}, stream and write out only those with v >= threshold to a new file while counting rejects.
Batching adapter
Write process_in_batches for JSON lines: parse with a decoder returning option, and consume writes each batch to a CSV file (append mode).
