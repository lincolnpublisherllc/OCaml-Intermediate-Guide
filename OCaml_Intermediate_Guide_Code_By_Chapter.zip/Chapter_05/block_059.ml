Streaming sum
Implement sum_file : string -> (int, string) result that reads integers (one per line), ignores blanks, returns an error if any non-integer line appears (include line number).
