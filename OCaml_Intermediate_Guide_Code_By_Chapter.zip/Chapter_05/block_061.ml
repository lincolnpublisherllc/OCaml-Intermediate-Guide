Aggregate with Map for deterministic outputs; convert to rows → strings at the end.
