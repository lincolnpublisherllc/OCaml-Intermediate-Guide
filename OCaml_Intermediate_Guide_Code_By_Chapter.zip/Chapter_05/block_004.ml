let rec loop acc =
      match input_line ic with
      | line -> loop (f acc line)
