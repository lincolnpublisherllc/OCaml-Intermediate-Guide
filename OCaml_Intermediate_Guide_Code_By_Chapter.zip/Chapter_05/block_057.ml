let rec step s () =
    match s () with
