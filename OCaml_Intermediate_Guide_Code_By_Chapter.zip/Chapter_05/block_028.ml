let open Result in
      let* sym_v = field "sym" obj in
      let* bid_v = field "bid" obj in
      let* ask_v = field "ask" obj in
      let* sym = get_string "sym" sym_v in
      let* bid = get_float "bid" bid_v in
      let* ask = get_float "ask" ask_v in
      if bid > ask then Error (J_range "bid<=ask") else
      Ok { sym = String.uppercase_ascii sym; bid; ask }
  | _ -> Error (J_type "root")
