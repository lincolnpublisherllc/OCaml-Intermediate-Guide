let write_file filename s =
  Out_channel.with_open_text filename (fun oc -> output_string oc s)
