type order = { sym : string; qty : int; px : float }
