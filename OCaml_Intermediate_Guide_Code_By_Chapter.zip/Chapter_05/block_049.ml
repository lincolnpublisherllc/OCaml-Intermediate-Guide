Unit test decoders with tiny inputs, good and bad.
