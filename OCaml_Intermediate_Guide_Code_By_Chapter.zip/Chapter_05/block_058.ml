let (chunk, rest) = take n [] s in
