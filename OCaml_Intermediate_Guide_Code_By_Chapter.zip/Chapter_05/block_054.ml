let seq_chunks n (s : 'a Seq.t) : 'a list Seq.t =
  let open Seq in
  let rec take k acc s =
