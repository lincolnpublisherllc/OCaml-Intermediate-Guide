let get_float name = function
