begin match decode line with
        | Some x -> loop ic (x :: acc) (n - 1)
        | None   -> loop ic acc (n - 1)   (* skip/record error elsewhere *)
