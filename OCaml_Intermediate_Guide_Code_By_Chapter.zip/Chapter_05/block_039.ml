let aggregate_orders filename : (agg M.t * (csv_err * int) list) =
  let { ok; errors } = load_orders filename in
  let m = List.fold_left add_order M.empty ok in
  (m, errors)
