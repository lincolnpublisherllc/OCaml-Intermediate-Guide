| xs -> Error (Bad_arity (List.length xs))
Streaming decode with error accounting
type 'a stats = { ok : 'a list; errors : (csv_err * int) list }
