let field name obj =
  match List.assoc_opt name obj with
