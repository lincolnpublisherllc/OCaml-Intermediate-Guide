let process_in_batches filename ~batch_size ~decode ~consume =
  let rec loop ic acc n =
    if n = 0 then (consume (List.rev acc); loop ic [] batch_size) else
    match input_line ic with
