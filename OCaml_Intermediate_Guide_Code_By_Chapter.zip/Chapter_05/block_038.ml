let add_order (m : agg M.t) (o : order) =
  let v = M.find_opt o.sym m |> Option.value ~default:{ qty = 0; notional = 0.0 } in
  let v' = { qty = v.qty + o.qty; notional = v.notional +. float_of_int o.qty *. o.px } in
