let decode_quote (j : Yojson.Basic.t) : (quote, jerr) result =
  match j with
