let bump key tbl =
  let n = Option.value ~default:0 (Hashtbl.find_opt tbl key) in
