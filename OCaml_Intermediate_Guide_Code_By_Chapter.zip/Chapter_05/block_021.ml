let get_string name = function
