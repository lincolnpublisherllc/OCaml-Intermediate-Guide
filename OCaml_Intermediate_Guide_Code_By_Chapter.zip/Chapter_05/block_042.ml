|> List.map (fun (sym, a) ->
       let vwap = if a.qty = 0 then 0.0 else a.notional /. float_of_int a.qty in
       { sym; qty = a.qty; notional = a.notional; vwap })
Step 5: output (CSV-friendly, deterministic order)
let render_rows rows =
  let header = "sym,qty,notional,vwap\n" in
  let body =
