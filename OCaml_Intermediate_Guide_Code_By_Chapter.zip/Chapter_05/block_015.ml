let load_orders filename : order stats =
  let errors = Hashtbl.create 16 in
  let ok =
    fold_lines filename ~init:[] ~f:(fun acc line ->
      match decode_order (split_csv_line line) with
