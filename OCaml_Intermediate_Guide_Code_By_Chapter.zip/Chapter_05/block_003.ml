let fold_lines filename ~init ~f =
