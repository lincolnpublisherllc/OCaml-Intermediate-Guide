let load_jsonl decode filename =
  fold_lines filename ~init:([], []) ~f:(fun (oks, errs) line ->
    match Yojson.Basic.from_string line |> decode with
    | Ok x   -> (x :: oks, errs)
    | Error e -> (oks, e :: errs))
  |> fun (oks, errs) -> (List.rev oks, List.rev errs)
