For unquoted CSV this is fine. For real CSV with quotes/escapes, use a proper CSV parser library when you add dependencies to your project (covered later in this book).
