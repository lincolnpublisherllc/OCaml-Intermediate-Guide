type csv_err =
