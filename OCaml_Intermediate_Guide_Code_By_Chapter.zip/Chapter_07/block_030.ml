let t = fetch "https://example.com" in
Lwt.cancel t;  (* cooperative; library code should check and stop *)
Notes:
