let timed_out = Atomic.make false in
    Fiber.fork ~sw (fun () ->
