try Ok (f ()) with
