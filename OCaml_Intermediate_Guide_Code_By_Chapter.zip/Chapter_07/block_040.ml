let actor () =
  let inbox = Lwt_mvar.create_empty () in
  let rec loop n =
    Lwt_mvar.take inbox >>= function
    | Inc -> loop (n+1)
    | Get k -> k n >>= fun () -> loop n
