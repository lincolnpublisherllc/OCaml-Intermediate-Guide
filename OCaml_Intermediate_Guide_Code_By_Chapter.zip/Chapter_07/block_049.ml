Bounded worker pool (Thread)
Build a mini image/CSV transformer that reads file names from a seq, processes with N workers, and writes outputs. Add a graceful shutdown signal.
Timeout wrapper (Lwt)
Write with_timeout : float -> 'a Lwt.t -> ('a, [> Timeout]) result Lwt.t`. Use it to bound an HTTP GET to 1.5s.
