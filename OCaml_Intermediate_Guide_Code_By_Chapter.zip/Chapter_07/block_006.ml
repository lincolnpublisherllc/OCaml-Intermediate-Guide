let par_sum (pool : Task.pool) (a : float array) =
  Task.parallel_for_reduce ~start:0 ~finish:(Array.length a - 1)
    ~body:(fun i -> a.(i))
    ~reduce:( +. )
