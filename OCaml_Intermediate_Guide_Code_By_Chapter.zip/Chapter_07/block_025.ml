let () = Eio_main.run @@ fun env ->
  match with_timeout env#clock 3.0 (fun () -> (* do work *) 42) with
