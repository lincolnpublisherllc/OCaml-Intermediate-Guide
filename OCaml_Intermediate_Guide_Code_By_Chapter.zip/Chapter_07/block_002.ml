7.1 Concurrency patterns with domains and threads
