let body =
      Net.get net (Uri.of_string url) |> Cstruct.to_string
