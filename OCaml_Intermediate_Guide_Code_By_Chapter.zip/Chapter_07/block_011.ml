let pop q =
