More practical example with cancellation timeout:
let with_timeout clock secs f =
