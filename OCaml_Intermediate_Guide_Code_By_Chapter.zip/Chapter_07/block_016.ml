Eio (effects-based, OCaml 5+): structured concurrency with Switch, fibers, cancellation propagation, modern I/O.
Lwt (promises): mature, huge ecosystem; works well for HTTP clients/servers, DB drivers.
