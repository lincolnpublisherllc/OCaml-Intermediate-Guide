7.4.3 Fan-out + gather with Lwt
let fetch_many urls =
