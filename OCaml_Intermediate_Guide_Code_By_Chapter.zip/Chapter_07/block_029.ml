let with_timeout secs p =
  Lwt.pick [ (Lwt_unix.sleep secs >|= fun () -> Error `Timeout)
           ; (p >|= fun v -> Ok v) ]
Structured tasks (simple form):
let concurrently ps = Lwt_list.fold_left_s (fun acc p ->
  p >|= fun v -> v :: acc) [] ps >|= List.rev
