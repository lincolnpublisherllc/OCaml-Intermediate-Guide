let fetch url =
  Cohttp_lwt_unix.Client.get (Uri.of_string url) >>= fun (_resp, body) ->
