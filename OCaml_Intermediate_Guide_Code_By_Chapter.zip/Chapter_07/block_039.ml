A simple actor with an inbox (Lwt):
type msg = Inc | Get of (int -> unit Lwt.t)
