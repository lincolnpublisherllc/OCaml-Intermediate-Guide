7.4.1 Parallel map with chunking (Domainslib)
let par_map pool ~chunk arr f =
  let n = Array.length arr in
  let out = Array.make n (Obj.magic ()) in
  Task.parallel_for ~start:0 ~finish:(n-1) ~body:(fun i ->
    out.(i) <- f arr.(i)) ~pool;
