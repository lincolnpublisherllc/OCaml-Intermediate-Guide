Unit test pure kernels (the function you run in parallel) in isolation.
