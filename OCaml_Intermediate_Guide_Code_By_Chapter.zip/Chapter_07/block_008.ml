parallel_for_reduce to combine with an associative operator.
