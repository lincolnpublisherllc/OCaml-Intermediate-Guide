A couple of background workers around shared state → Threads with Mutex/Condition.
Actor style (mailboxes, message passing) → build on Eio fibers or Lwt mailboxes; isolate state per actor.
