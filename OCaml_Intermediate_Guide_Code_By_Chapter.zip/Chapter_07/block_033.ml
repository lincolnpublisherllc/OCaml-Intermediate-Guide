Don’t mix models inside the same module. If you must, keep a thin adapter layer.
