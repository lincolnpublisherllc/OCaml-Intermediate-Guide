7.1.1 Parallel map/reduce with Domainslib
