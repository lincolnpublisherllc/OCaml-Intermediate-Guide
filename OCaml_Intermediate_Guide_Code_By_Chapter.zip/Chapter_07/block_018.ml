let fetch_and_log ~net ~clock url =
