let start_pool ~workers ~handle job_seq =
  let q = { q = Queue.create (); m = Mutex.create (); c = Condition.create (); cap = 1024 } in
  let _ws = Array.init workers (fun _ -> worker q handle) in
