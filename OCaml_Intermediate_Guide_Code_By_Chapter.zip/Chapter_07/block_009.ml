7.1.2 Classic threads with locks and conditions
Use when you must share a mutable object (e.g., bounded queue) or manage blocking I/O without adopting an async framework.
type 'a queue = {
