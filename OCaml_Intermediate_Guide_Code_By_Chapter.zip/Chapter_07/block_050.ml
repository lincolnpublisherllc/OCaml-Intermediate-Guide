Choose Eio for structured async with cancellation; Lwt if you want a promise ecosystem today.
