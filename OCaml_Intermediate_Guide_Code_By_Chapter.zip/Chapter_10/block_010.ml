type sym = string
type trade = { sym : sym; qty : int; px : float; ts : int }  (* epoch seconds *)
