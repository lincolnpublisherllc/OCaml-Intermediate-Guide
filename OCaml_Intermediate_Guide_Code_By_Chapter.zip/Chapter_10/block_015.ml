match int_of_string_opt qty_s, float_of_string_opt px_s, int_of_string_opt ts_s with
  | Some q, Some p, Some ts when q > 0 && p > 0. -> Ok { sym; qty=q; px=p; ts }
