type agg = { qty:int; notional:float }
type row = { sym:string; qty:int; notional:float; vwap:float }
