type err = Empty_sym | Bad_qty | Bad_px
let pp_err fmt = function
