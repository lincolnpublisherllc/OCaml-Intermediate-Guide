let connect uri =
  let open Lwt_result.Syntax in
