let add a q px =
  { qty = a.qty + q; notional = a.notional +. (float_of_int q *. px) }
