Building a Mid-Sized Project (REST API / CLI Tool / Simulation)
We’ll build a realistic REST API service for analytics: ingest trades, compute per-symbol metrics, and serve results. You’ll see how to design modules, keep persistence and services separate, add observability (logs/metrics/traces), manage config, ship reliable releases, and (optionally) bolt on a tiny web UI or report generator.
Everything here scales down to a CLI or up to a small simulation with the same structure.
