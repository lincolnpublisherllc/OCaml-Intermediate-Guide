let* (module Db : C.CONNECTION) = C.connect (Uri.of_string uri) in
  Ok (Db :> t)
