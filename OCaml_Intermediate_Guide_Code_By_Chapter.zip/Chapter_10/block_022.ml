let rows_of_map m =
