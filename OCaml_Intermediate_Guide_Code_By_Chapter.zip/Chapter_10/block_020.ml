let of_trades ts =
