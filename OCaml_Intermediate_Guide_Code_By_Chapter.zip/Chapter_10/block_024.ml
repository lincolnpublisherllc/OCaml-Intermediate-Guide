10.4 Store: a signature with two implementations
