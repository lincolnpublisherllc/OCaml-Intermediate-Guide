libs/store/store_sql.ml (sketch)
module C = Caqti_lwt
type err = Conn of string | Sql of string
type t = C.connection
