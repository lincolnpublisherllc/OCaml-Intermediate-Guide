let of_row sym_s qty_s px_s ts_s =
  let open Option in
  let sym = String.uppercase_ascii (String.trim sym_s) in
