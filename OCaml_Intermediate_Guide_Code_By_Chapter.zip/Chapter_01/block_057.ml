Next up: a practical project workspace with OPAM and Dune, reproducible builds, and the developer tooling that keeps teams moving.
