(* Return the median of a sorted int list if length odd, else average of the two middle as float *)
let median_sorted = function
  | [] -> None
  | [x] -> Some (float_of_int x)
