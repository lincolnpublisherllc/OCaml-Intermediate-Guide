let parse_line sym_s qty_s px_s =
  let* qty = parse_qty qty_s in
  let* px  = parse_px  px_s  in
  Ok { sym = String.uppercase_ascii sym_s; qty; px }
