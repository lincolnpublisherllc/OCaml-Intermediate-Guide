module type ORDERED = sig type t val compare : t -> t -> int end
module Make_set (Ord : ORDERED) = struct
  module S = Set.Make(Ord)
  include S
  let of_list xs = List.fold_left (fun acc x -> S.add x acc) S.empty xs
