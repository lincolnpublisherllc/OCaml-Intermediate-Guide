module Make_cache (C : CLOCK) = struct
  let created = C.now ()
  let mutable hits = 0
  let get () = hits <- hits + 1; (created, hits)
