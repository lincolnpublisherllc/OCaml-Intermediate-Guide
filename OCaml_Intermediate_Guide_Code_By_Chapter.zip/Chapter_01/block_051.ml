Build with :: then List.rev once.
