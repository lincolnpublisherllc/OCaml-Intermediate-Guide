type currency = NGN | USD | EUR
type quote = { sym:string; bid:float; ask:float; ccy:currency }
