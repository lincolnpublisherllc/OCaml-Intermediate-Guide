|> Option.bind (fun n -> if n > 0 then Some n else None)
Variant: Return ('a, string) result with friendly error messages.
Drill E — Result with let-operators
let ( let* ) r f = match r with Ok x -> f x | Error e -> Error e
let ( let+ ) r f = match r with Ok x -> Ok (f x) | Error e -> Error e
