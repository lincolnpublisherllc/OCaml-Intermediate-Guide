(* Alias, record, variant *)
type price = float
type trade = { id:int; symbol:string; qty:int; px:price }
type side = Buy | Sell
