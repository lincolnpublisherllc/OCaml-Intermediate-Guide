type ccy = NGN | USD | EUR | Other of string
type q = { sym:string; bid:float; ask:float; mid:float; ccy:ccy }
Rules:
bid and ask must parse to positive floats with bid <= ask.
