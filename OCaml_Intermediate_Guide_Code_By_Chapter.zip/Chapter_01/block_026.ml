let mid = function {bid; ask; _} -> (bid +. ask) /. 2.0
