These are short, focused reps. Write the function, think about exhaustiveness, and keep branches simple.
