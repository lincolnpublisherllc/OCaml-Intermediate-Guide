let xs = [1;2;3] |> List.filter ((<) 1) |> List.map (( * ) 10)
let a = [|1;2;3|] in a.(1) <- 20
module S = Set.Make(String)
module M = Map.Make(String)
