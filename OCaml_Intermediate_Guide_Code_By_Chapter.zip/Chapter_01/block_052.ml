Exercise 1 — Position summary
Given type pos = Long | Short | Flat, and a list of trades, return a (pos * int) summary: counts per position based on sign of qty (>0 long, <0 short, =0 flat). Use a Map keyed by pos and return a record {long; short; flat}.
Exercise 2 — Parse and value
Parse a CSV row "SYM,qty,px" to {sym; qty; px} with result. Return the line’s notional as Ok float, or a detailed error. Use let*.
Exercise 3 — Price module
Extend Price with add : t -> t -> t option that returns None on overflow if to_float a + to_float b exceeds a ceiling you choose. Keep the ceiling private.
Exercise 4 — Rolling median (outline only)
Define an interface ROLLING with push : t -> float -> unit and median : t -> float option. Sketch two implementations: one with two heaps (balanced), one with a tree (Map) of counts. State tradeoffs in comments.
