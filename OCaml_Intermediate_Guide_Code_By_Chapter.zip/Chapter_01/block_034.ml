type line = {sym:string; qty:int; px:float}
