let%test _ = discount 100. ~rate:0.1 = 90.
