module Stdout_log : LOG = struct
  let info s = Printf.printf "[INFO] %s\n" s
