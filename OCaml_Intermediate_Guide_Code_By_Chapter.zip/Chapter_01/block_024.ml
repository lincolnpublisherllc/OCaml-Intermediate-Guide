let a = List.nth xs (n/2 - 1) and b = List.nth xs (n/2) in
      Some ((float_of_int a +. float_of_int b) /. 2.0)
Improve: Rewrite to avoid List.nth with a single pass using indices and pattern matching. Aim for O(n) with no random access.
