Avoid repeated @. Build with ::, then List.rev.
