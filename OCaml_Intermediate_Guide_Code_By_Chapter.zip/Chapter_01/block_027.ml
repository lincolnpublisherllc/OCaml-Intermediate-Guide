let fx_symbol = function
