let discount (p:price) ~rate = p *. (1.0 -. rate)
let compose f g x = f (g x)
let ( |> ) x f = f x     (* pipe *)
// or open Stdlib to use (|>)
