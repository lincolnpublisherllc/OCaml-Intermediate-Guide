(* GADTs (light touch here; we’ll go deeper later) *)
type _ expr =
