The goal is to move from ad-hoc match blocks to readable flows that short-circuit on failure, while keeping control of errors.
