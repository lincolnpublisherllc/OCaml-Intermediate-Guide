let total l = float_of_int l.qty *. l.px
Try: Add currency parsing as a third validated field and carry an error type instead of string.
