(* price.ml *)
type t = P of float
let of_float x = if x >= 0. then Some (P x) else None
let to_float (P x) = x
let discount (P x) ~rate = P (x *. (1.0 -. rate))
Try: Enforce invariants (non-negative) only through the constructor. Add a pp : Format.formatter -> t -> unit.
