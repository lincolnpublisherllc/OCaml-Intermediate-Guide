let parse_px s =
  match float_of_string_opt s with
