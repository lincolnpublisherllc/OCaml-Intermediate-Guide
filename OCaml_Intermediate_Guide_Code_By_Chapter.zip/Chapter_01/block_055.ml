If any row fails, keep the successful ones and produce an aggregate Error with counts of failures by reason.
Constraints:
Use a small error type with cases BadFloat of string | BadSpread | BadCcy of string.
Use result combinators (let*, let+).
Split into Normalise (logic) and Normalise_cli (I/O) modules.
