let parse_qty s =
  match int_of_string_opt s with
