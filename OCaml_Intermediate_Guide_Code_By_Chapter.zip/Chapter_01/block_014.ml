let line = Printf.sprintf "%s,%d,%.4f" sym qty px
let lines = In_channel.with_open_text "file.csv" In_channel.input_all
