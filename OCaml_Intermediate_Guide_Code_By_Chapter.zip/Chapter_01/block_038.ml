let load_env key =
  of_opt ~err:("missing "^key) (Sys.getenv_opt key)
Try: Compose load_env "API_KEY" with a parsing function that validates length and allowed characters.
