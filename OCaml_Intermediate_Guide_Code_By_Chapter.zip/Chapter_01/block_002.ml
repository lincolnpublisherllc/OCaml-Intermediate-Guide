(* Parametric types *)
type 'a box = Box of 'a
