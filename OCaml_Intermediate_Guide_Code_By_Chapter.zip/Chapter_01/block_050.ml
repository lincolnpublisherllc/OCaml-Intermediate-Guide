Both branches return the same type.
