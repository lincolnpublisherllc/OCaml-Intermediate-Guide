module type CLOCK = sig val now : unit -> float end
module Sys_clock : CLOCK = struct let now () = Unix.gettimeofday () end
