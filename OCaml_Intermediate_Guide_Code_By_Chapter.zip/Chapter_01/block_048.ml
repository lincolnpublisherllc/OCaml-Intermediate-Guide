let tickers = Sym_set.of_list ["AAPL";"MSFT";"AAPL"] |> Sym_set.elements
Try: Create a Make_cache functor that accepts a CLOCK and exposes get : key -> value option and put.
