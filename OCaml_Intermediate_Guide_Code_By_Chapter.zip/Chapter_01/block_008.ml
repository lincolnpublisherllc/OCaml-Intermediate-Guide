let find_opt ~id rows =
  List.find_opt (fun r -> r.id = id) rows
