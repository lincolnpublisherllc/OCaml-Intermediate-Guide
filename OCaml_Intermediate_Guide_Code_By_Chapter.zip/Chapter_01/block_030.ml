(* Extract "qty" from a string dict; ensure > 0 *)
let find qty_key kvs =
  let open Option in
