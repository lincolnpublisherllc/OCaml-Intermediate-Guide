What does let* do in a result pipeline
