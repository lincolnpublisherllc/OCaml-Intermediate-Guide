let of_opt ~err = function Some x -> Ok x | None -> Error err
