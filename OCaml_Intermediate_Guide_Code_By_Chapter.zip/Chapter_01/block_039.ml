At this level you should separate concerns with small modules and use signatures to lock APIs. Start with tiny, useful components.
