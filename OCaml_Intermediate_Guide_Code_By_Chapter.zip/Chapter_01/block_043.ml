let run (module L : LOG) =
  L.info "starting"; (* ... *) L.info "done"
