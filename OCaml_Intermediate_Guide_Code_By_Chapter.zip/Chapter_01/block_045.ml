let () = run (module Stdout_log)
