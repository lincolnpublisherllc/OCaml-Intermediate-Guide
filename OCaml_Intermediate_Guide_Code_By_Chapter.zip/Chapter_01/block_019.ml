(* Return "big buy", "big sell", "small" *)
let classify o =
  match o with
  | { side = Buy; qty } when qty >= 10_000 -> "big buy"
  | { side = Sell; qty } when qty >= 10_000 -> "big sell"
