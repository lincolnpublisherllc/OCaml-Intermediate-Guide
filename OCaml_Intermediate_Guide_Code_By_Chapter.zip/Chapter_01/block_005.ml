let notional t =
  match t with
  | { qty; px; _ } -> float_of_int qty *. px
