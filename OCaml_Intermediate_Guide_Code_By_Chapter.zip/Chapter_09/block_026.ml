let () = exit (Cmd.eval cmd)
Subcommands are just multiple Cmd.v values composed with Cmd.group.
Guidelines:
