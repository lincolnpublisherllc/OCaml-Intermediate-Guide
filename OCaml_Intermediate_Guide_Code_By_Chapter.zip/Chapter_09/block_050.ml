type out = { sym:string; mid:float }
