let get_text url =
  Cohttp_lwt_unix.Client.get (Uri.of_string url) >>= fun (_r, body) ->
