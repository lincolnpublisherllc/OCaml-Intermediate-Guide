let as_float name = function
