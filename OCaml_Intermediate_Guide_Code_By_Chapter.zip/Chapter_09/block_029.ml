type order = { sym : string; qty : int; px : float }
type csv_err = Bad_arity of int | Bad_int of string | Bad_float of string
