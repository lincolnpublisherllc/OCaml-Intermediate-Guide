Library packaging
Split out your CSV decoder into lib/csvx with .mli and publishable metadata. Add inline tests and generate docs.
Plot export
Export a time series to CSV and plot it with your preferred tool. Commit the script and a golden PNG to your repo.
