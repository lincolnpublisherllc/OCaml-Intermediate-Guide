let write_series file xs =
