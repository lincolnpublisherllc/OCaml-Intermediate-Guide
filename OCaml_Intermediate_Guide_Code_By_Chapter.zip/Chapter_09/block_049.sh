opam install odoc
dune build @doc
