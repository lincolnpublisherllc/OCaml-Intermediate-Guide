9.3.2 Effects style with Eio
(* dune: (libraries eio_main) *)
let () = Eio_main.run @@ fun env ->
  let body = Eio.Net.get env#net (Uri.of_string "https://example.com") in
  let s = Cstruct.to_string body in
