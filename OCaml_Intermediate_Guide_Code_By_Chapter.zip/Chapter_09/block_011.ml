let open Result in
      let* sym = field "sym" obj |> Result.bind (as_string "sym") in
      let* bid = field "bid" obj |> Result.bind (as_float "bid") in
      let* ask = field "ask" obj |> Result.bind (as_float "ask") in
      if bid <= ask then Ok { sym = String.uppercase_ascii sym; bid; ask }
      else Error (Range "bid<=ask")
  | _ -> Error (Type "root")
