let fmt t =
  match Ptime.to_rfc3339 t with
