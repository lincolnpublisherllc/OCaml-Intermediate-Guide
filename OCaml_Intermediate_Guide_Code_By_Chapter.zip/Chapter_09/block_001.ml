Here’s a practical shortlist you can mix and match. You don’t need all of them on day one.
JSON: yojson (explicit decoders, easy to debug).
HTTP: cohttp-lwt-unix (promise style) or eio + its HTTP helpers (effects style).
CLI: cmdliner (robust flags, help text, subcommands).
