let decode_order = function
  | [sym; qty_s; px_s] ->
      begin match int_of_string_opt qty_s, float_of_string_opt px_s with
      | Some q, Some p when q > 0 && p > 0. -> Ok { sym = String.uppercase_ascii sym; qty = q; px = p }
      | None, _ -> Error (Bad_int qty_s)
      | _, None -> Error (Bad_float px_s)
      | _ -> Error (Bad_float px_s)
