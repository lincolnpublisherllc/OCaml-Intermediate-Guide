Fail with a readable message and nonzero exit.
