let infile =
  let doc = "Input CSV file." in
  Arg.(required & pos 0 (some file) None & info [] ~docv:"FILE" ~doc)
