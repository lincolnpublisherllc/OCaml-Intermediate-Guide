(* dune: (libraries ptime) *)
let now () = Ptime_clock.now ()
let add_days t d =
  match Ptime.add_span t (Ptime.Span.of_int_s (d * 86_400)) with
