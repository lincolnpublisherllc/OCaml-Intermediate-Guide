let to_out q = { sym = q.sym; mid = (q.bid +. q.ask) /. 2.0 }
