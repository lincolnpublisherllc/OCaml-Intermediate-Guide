let lines = String.split_on_char '\n' s in
  let oks, _errs =
    List.fold_left (fun (ok, er) l ->
      if l = "" then (ok, er) else
      match Yojson.Basic.from_string l |> decode_quote with
      | Ok q -> (to_out q :: ok, er)
      | Error e -> (ok, e :: er))
      ([], []) lines
