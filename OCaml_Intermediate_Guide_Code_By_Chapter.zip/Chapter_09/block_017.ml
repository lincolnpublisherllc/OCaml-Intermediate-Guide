let with_timeout secs p =
  Lwt.pick [ (Lwt_unix.sleep secs >|= fun () -> Error `Timeout)
           ; (p >|= fun v -> Ok v) ]
