(* dune: (libraries yojson) *)
type quote = { sym : string; bid : float; ask : float }
