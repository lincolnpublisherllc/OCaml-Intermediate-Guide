let render_csv rows =
  let b = Buffer.create 1024 in
