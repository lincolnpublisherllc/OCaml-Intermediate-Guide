let threshold =
  let doc = "Minimum value to keep." in
  Arg.(value & opt float 0.0 & info ["t"; "threshold"] ~doc ~docv:"FLOAT")
