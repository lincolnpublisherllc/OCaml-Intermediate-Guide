9.3.1 Promise style with Lwt
(* dune: (libraries cohttp-lwt-unix lwt) *)
open Lwt.Infix
