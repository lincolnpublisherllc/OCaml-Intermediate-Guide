type cfg = { url : string; threshold : float }
