9.4 Command-line UX with Cmdliner
