(* Example *)
let () =
  let run =
    with_timeout 2.5 (get_text "https://example.com") >|= function
    | Ok s -> print_endline (String.sub s 0 (min 80 (String.length s)))
