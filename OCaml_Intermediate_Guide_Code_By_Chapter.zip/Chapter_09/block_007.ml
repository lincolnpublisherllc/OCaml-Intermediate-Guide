let as_string name = function
  | `String s -> Ok s | _ -> Error (Type name)
