Package libraries with clear interfaces, docs, and versioned releases.
