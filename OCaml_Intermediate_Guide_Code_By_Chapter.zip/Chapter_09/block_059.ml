Make CLIs friendly and safe with cmdliner.
Keep HTTP bounded with timeouts and retries.
