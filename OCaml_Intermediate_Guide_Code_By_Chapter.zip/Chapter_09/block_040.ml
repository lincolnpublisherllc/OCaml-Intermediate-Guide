let cfg_of_env () =
  let url = Sys.getenv_opt "APP_URL" in
  let threshold =
