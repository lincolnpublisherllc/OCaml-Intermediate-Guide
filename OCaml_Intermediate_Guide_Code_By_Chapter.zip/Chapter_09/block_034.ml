let () =
  let t = now () in
  Printf.printf "now=%s +1d=%s\n" (fmt t) (fmt (add_days t 1))
