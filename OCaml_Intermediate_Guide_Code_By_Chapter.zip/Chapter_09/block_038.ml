List.iter (fun {t;v} -> Printf.fprintf oc "%d,%.6f\n" t v) xs
Then plot with your preferred tool (gnuplot, Python, etc.). If you want OCaml-native plots, look for a binding that suits your environment and slot it in behind a tiny module signature so you can swap later.
