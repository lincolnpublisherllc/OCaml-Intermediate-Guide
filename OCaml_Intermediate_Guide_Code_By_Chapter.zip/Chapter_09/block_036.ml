type point = { t:int; v:float }
