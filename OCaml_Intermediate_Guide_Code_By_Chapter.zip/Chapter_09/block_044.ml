let get k = List.assoc_opt k o in
        let url = Option.bind (get "url") (function `String s -> Some s | _ -> None) in
        let threshold =
          Option.bind (get "threshold") (function
            | `Float x -> Some x | `Int i -> Some (float_of_int i) | _ -> None)
