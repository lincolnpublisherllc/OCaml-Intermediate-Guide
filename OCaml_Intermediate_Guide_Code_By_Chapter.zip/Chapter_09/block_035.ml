For many tools work, the fastest path is to export CSV and plot with a scriptable tool. Keep plotting separate from computation.
