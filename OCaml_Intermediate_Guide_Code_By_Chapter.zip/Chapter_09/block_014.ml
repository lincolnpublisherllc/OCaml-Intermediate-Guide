let load_jsonl decode file =
  fold_lines file ~init:([], []) ~f:(fun (oks, errs) line ->
    match Yojson.Basic.from_string line |> decode with
    | Ok x -> (x :: oks, errs)
    | Error e -> (oks, e :: errs))
  |> fun (oks, errs) -> (List.rev oks, List.rev errs)
