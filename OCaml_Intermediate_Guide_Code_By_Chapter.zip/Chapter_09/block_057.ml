CLI + JSON
Build quotes-cli with cmdliner that fetches a URL (flag), decodes JSON lines with yojson, and prints the top 5 mids.
