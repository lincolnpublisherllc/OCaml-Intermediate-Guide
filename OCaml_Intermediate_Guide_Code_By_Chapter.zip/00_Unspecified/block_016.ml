A library with pure domain modules for positions, scenarios, and risk.
A store with a typed boundary and at least two implementations, one in memory and one backed by a database.
