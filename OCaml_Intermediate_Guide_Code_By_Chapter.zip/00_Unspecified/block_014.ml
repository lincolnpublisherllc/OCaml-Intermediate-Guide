We document in .mli files with short runnable examples and we run those examples as tests.
