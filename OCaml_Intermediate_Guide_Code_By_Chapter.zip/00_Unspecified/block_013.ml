We prefer result over exceptions at module boundaries. Callers should not need try to use your library.
