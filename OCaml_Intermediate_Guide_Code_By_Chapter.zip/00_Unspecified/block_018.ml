Tests that cover logic, I/O boundaries, and end-to-end behavior with golden outputs.
