Database integration with typed SQL, migrations, paging, and connection pools.
Performance work that starts with measuring. You will look at allocations, tidy hot paths, and keep memory stable under load.
