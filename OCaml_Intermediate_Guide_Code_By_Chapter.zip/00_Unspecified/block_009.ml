Code organization at scale: module hierarchies, interface files that set boundaries, and functors or first-class modules for dependency injection.
Data structures in depth: when to pick Map/Set over Hashtbl, how balanced trees work, and how to avoid tuple soup with small records.
