Closing material with a capstone project and a study plan for advanced topics.
