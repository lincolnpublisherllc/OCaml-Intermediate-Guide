Sets, maps, and trees used with custom comparators, and when a hash table is the right call.
