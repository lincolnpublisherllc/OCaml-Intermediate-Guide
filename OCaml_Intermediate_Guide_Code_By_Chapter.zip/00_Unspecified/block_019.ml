If you carry these forward, you can pick up stronger type techniques, formal methods where they help, and bigger architectures without losing clarity.
