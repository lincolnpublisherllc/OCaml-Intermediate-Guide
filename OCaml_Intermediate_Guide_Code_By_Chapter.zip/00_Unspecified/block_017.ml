A CLI with helpful flags and examples, plus a REST API with health checks and clear errors.
