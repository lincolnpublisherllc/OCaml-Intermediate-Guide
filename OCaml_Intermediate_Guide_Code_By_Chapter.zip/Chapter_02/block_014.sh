# build everything
dune build
