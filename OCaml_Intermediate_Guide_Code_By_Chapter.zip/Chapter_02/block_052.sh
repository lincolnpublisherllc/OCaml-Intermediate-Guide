dune build — verify it shows up.
Add it as a dependency in an app’s dune file: (libraries curve_fit timeseries).
