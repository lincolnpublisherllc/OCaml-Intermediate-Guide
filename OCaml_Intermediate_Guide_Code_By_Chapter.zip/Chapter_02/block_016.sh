# pick an explicit compiler version for reproducibility
opam switch create . ocaml-base-compiler.5.2.1
eval "$(opam env)"
