Team with conventional OPAM workflows: A.
