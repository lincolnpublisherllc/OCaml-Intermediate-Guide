Don’t leave the compiler version floating. Pin it (e.g., ocaml-base-compiler.5.2.1) so binary interfaces match across machines.
