eval $(opam env)
          dune build @fmt --auto-promote=false
