Make a directory libs/curve_fit/ with dune, src/, and a stub .ml.
