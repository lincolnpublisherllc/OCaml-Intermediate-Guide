# format in place
dune fmt
