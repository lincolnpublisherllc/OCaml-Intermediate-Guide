opam switch create . ocaml-base-compiler.5.2.1
          eval $(opam env)
          opam install . --deps-only --locked -y
