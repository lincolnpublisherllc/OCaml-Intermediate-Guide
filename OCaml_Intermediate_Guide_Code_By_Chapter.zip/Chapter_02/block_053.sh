opam lock . to refresh lockfiles.
