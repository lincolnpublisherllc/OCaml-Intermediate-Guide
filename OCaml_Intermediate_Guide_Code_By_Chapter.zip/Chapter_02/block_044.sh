.PHONY: setup deps build test fmt fmt-check lint
setup:
	opam switch create . ocaml-base-compiler.5.2.1 || true
	eval $$(opam env); opam install . --deps-only -y
