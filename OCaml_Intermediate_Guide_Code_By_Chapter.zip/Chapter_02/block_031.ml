Pick a test framework you like (alcotest, ounit2, or ppx_inline_test). Example with ppx_inline_test:
