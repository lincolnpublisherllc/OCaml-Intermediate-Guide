dune at repo root:
(alias
 (name lint)
 (deps
