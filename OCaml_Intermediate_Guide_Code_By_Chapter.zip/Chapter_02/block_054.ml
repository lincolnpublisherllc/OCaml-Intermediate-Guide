Wide-open warnings: turn them on in dev so problems are found early; relax in release if needed.
Regenerating opam files: if (generate_opam_files true), remember that Dune may overwrite your manual edits—keep the source of truth clear.
