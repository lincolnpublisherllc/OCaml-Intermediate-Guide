# run the CLI (Dune will find the executable)
dune exec quote_cli
Tip: If you want separate build “contexts” (e.g., dev vs release flags), add a dune-workspace file and define contexts there. Most teams start without it and only add one when they need cross-compilation or special flags.
