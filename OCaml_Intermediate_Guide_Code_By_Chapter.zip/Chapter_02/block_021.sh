# update dependencies (while keeping lock files in sync)
opam update
opam upgrade            # review carefully in a team setting
opam lock .             # refresh lockfiles after changes
opam install . --deps-only --locked
