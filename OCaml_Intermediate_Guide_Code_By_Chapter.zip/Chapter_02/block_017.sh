# install deps declared by your packages
opam install . --deps-only -y
