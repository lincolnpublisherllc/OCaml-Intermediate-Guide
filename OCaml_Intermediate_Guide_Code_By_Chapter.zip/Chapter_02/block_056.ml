Introduce a badly formatted file; confirm CI catches it with the @fmt check.
