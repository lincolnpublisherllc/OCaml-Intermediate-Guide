# CI mode: check without changing files
dune build @fmt --auto-promote=false
